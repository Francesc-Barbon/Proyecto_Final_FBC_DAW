@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Bienvenido a EasyHome</h1>
    </div>
@endsection
