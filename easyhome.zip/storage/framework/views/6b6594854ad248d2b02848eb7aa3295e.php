<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="mb-4">
            <?php if(auth()->user()->role === 'admin'): ?>
                Dashboard de administración
            <?php else: ?>
                Mi desempeño
            <?php endif; ?>
        </h2>
        <?php if(auth()->user()->role === 'admin'): ?>
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="card text-bg-success">
                        <div class="card-header">Coste total en mano de obra</div>
                        <div class="card-body">
                            <h4><?php echo e(number_format($totalLaborCost, 2)); ?> €</h4>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card text-bg-warning">
                        <div class="card-header">Coste total en materiales</div>
                        <div class="card-body">
                            <h4><?php echo e(number_format($totalMaterialCost, 2)); ?> €</h4>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card text-bg-danger">
                        <div class="card-header">Coste total de la empresa</div>
                        <div class="card-body">
                            <h4><?php echo e(number_format($totalCompanyCost, 2)); ?> €</h4>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <div class="row">
            <?php $__currentLoopData = $userStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card shadow-sm">
                        <div class="card-header bg-info text-white">
                            <?php echo e($stats['user']->name); ?>

                        </div>
                        <div class="card-body">
                            <p><strong>Trabajos realizados:</strong> <?php echo e($stats['jobCount']); ?></p>
                            <p><strong>Horas trabajadas:</strong> <?php echo e(number_format($stats['totalHours'], 2)); ?> h</p>
                            <p><strong>Costo generado:</strong> <?php echo e(number_format($stats['totalCost'], 2)); ?> €</p>
                            <p><strong>Materiales gestionados:</strong> <?php echo e($stats['materialsManaged']); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/user/dashboard.blade.php ENDPATH**/ ?>