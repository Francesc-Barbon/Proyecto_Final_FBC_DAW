 <!-- o el layout que uses -->

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="mb-4">Historial de Movimientos de Stock</h2>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table table-striped">
            <thead>
            <tr>
                <th>Fecha</th>
                <th>Material</th>
                <th>Cantidad</th>
                <th>Tipo de Movimiento</th>
                <th>Usuario</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($movement->date); ?></td>
                    <td><?php echo e($movement->material_name ?? 'Material eliminado'); ?></td>
                    <td><?php echo e($movement->quantity); ?></td>
                    <td><?php echo e(ucfirst($movement->movement_type)); ?></td>
                    <td><?php echo e($movement->user_name ?? 'Usuario eliminado'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/stock_movements/index.blade.php ENDPATH**/ ?>