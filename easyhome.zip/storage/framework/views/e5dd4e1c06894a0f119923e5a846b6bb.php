<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Detalles del Trabajo</h2>

        <div class="card mb-3">
            <div class="card-body">
                <h5 class="card-title">Descripción: <?php echo e($job->description); ?></h5>
                <p><strong>Fecha de Inicio:</strong> <?php echo e($job->start_date); ?></p>
                <p><strong>Fecha de Fin:</strong> <?php echo e($job->end_date ?? 'No especificada'); ?></p>
                <p><strong>Estado:</strong> <?php echo e(ucfirst($job->status)); ?></p>
                <p><strong>Responsable:</strong> <?php echo e($job->user->name); ?></p>
            </div>
        </div>

        
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link active" id="materials-tab" data-bs-toggle="tab" href="#materials" role="tab" aria-controls="materials" aria-selected="true">Materiales Asignados</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="hours-tab" data-bs-toggle="tab" href="#hours" role="tab" aria-controls="hours" aria-selected="false">Horas de Trabajo</a>
            </li>
        </ul>

        <div class="tab-content mt-4" id="myTabContent">
            
            <div class="tab-pane fade show active" id="materials" role="tabpanel" aria-labelledby="materials-tab">
                <h3>Materiales Asignados</h3>
                <?php if($stockMovements->isEmpty()): ?>
                    <p>No hay materiales asignados a este trabajo.</p>
                <?php else: ?>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>Material</th>
                            <th>Cantidad</th>
                            <th>Tipo de Movimiento</th>
                            <th>Fecha</th>
                            <th>Usuario</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $stockMovements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($movement->material->name); ?></td>
                                <td><?php echo e($movement->quantity); ?></td>
                                <td><?php echo e(ucfirst($movement->movement_type)); ?></td>
                                <td><?php echo e($movement->date); ?></td>
                                <td><?php echo e($movement->user->name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>

                <h3 class="mt-4">Agregar Material al Trabajo</h3>
                <form action="<?php echo e(route('jobs.addMaterial', $job->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="material_id" class="form-label">Seleccionar Material</label>
                        <select class="form-control" id="material_id" name="material_id" required>
                            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($material->id); ?>" data-quantity="<?php echo e($material->quantity); ?>">
                                    <?php echo e($material->name); ?> - <?php echo e($material->quantity); ?> disponible
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="quantity" class="form-label">Cantidad a Asignar</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" min="1" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Añadir Material</button>
                </form>
            </div>

            
            <div class="tab-pane fade" id="hours" role="tabpanel" aria-labelledby="hours-tab">
                <h3>Horas de Trabajo Asignadas</h3>

                <?php if($job->workHours->isEmpty()): ?>
                    <p>No hay horas registradas para este trabajo.</p>
                <?php else: ?>
                    <table class="table table-bordered">
                        <thead class="table-light">
                        <tr>
                            <th>Usuario</th>
                            <th>Horas</th>
                            <th>Fecha de Registro</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $job->workHours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($hour->user->name); ?></td>
                                <td><?php echo e($hour->hours); ?></td>
                                <td><?php echo e($hour->created_at->format('d/m/Y H:i')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>

                <h4 class="mt-4">Asignarte Horas</h4>

                <form action="<?php echo e(route('jobs.addHours', $job->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="hours" class="form-label">Horas a Registrar</label>
                        <input type="number" step="0.1" min="0.1" max="24" class="form-control" id="hours" name="hours" required>
                    </div>

                    <button type="submit" class="btn btn-success">Registrar Horas</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/jobs/show.blade.php ENDPATH**/ ?>