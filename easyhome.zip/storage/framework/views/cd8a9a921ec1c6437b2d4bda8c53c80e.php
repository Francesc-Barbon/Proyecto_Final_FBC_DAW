<?php $__env->startSection('content'); ?>
<body class="p-5">
<div class="container">

    <div class="container mt-5 pt-4">
        <h1 class="mb-4">Materiales</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
            </div>
        <?php endif; ?>
        <a href="<?php echo e(route('materials.create')); ?>" class="btn btn-primary mb-3">Añadir Nuevo Material</a>
        <h3 class="mt-4">Lista de Materiales</h3>
        <table class="table table-striped mt-3">
            <thead class="table-dark">
            <tr>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Cantidad</th>
                <th>Acciones</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($material->name); ?></td>
                    <td><?php echo e($material->description); ?></td>
                    <td><?php echo e($material->quantity); ?></td>
                    <td class="d-flex gap-2">
                        <a href="<?php echo e(route('materials.edit', $material->id)); ?>" class="btn btn-warning btn-sm">Almacén</a>
                        <form action="<?php echo e(route('materials.destroy', $material->id)); ?>" method="POST" onsubmit="return confirm('¿Estás seguro de eliminar este material?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($materials->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/materials/index.blade.php ENDPATH**/ ?>