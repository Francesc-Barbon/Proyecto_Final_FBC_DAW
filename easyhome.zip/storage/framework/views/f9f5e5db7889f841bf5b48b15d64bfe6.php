 <!-- o usa tu layout base -->

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Editar Cantidad de Material: <?php echo e($material->name); ?></h2>

        <form method="POST" action="<?php echo e(route('materials.update', $material->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3">
                <label for="movement_type" class="form-label">Tipo de Movimiento</label>
                <select name="movement_type" id="movement_type" class="form-select" required>
                    <option value="added">Entrada</option>
                    <option value="removed">Salida</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="quantity" class="form-label">Cantidad</label>
                <input type="number" name="quantity" id="quantity" class="form-control" min="1" required>
            </div>

            <button type="submit" class="btn btn-primary">Actualizar</button>
            <a href="<?php echo e(route('materials.index')); ?>" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/materials/edit.blade.php ENDPATH**/ ?>